<?php

//should be fine in most cases
  $mysql_host   = "localhost";

//you MUST change the user and pass!
  $mysql_user   = "user";
  $mysql_pass   = "pass";

//change if you want
  $mysql_dbname = "McData";

     /////////////////////////////////////////////////////
    //        thats all you need to edit!              //
   /////////////////////////////////////////////////////

if($_GET['adminlogin'] == 1)
{
	setcookie("mcdata-admin",1,1341464141,"","",0);
	$loggingin = 1;
	$refresh = 1;
}

if($_GET['adminlogout'] == 1)
{
	setcookie("mcdata-admin");
	$loggingout = 1;
	$refresh = 1;
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
	<?php 	if($loggingin == 1) echo "Setting cookie...";
		if($loggingout == 1) echo "Removing cookie...";
		if($refresh == 1) { ?> <meta http-equiv="refresh" content="0;url=<?php echo $_SERVER['PHP_SELF'] ?>"> <?php return; } ?>
	<title>Mcdata Diagnostics</title>
	<style type="text/css">
	body,div,td	{	font-family: 		arial, helvetica, sans-serif;	}
	</style>
</head>

<body>

<?php

echo "<h1>MySQL diag</h1>";
//db
echo "Connecting to MySQL...<br /><br />";
$db = mysql_connect($mysql_host,$mysql_user,$mysql_pass) or die("Couldnt connect to MySQL");

echo "Successfully connected to MySQL!";

echo "<hr />";

echo "<h1>Database diag</h1>";

$db_list = mysql_list_dbs($db);

while ($row = mysql_fetch_object($db_list))
{
	if($row->Database == $mysql_dbname)
	{
		$mcdatafound = 1;
		echo "Database \"" . $mysql_dbname . "\" found...<br /><br />";
	}
	if($mcdatafound == 1)
		break;
}

if($mcdatafound != 1)
{
	$query = "create database " . $mysql_dbname;
	mysql_query($query) or die("Couldnt create database :(");
	echo "Database \"" . $mysql_dbname . "\" created<br /><br />";
}
else
	echo "Passed!";

echo "<hr />";

echo "<h1>Table diag</h1>";
//if we got to this point, nothing should go wrong.
//table

$table_list = mysql_list_tables($mysql_dbname);

while($trow = mysql_fetch_row($table_list))
{
	if($trow[0] == "posts")
	{
		$postsfound = 1;
		echo "Table \"posts\" found...<br /><br />";
	}
	if($postsfound == 1)
		break;
}

if($postsfound != 1)
{
	$query = "create table posts (name VARCHAR(24) NOT NULL,date VARCHAR(24) NOT NULL,message TEXT NOT NULL,parentid INT NOT NULL,mid INT NOT NULL AUTO_INCREMENT,PRIMARY KEY (mid))";
	mysql_query($query) or die("Couldnt create table :(");
	echo "Table \"posts\" created...<br /><br />";
}
else
	echo "Passed!";

echo "<hr />";

echo "McData is ready for action!";

echo "<hr />";

?><h1>Admin Access</h1>

<?php	if($_COOKIE['mcdata-admin'] == 1)
	{
		?>
		<strong><a href="<?php echo $_SERVER['PHP_SELF'] ?>?adminlogout=1">Log out of admin mode</a></strong>.<br /><br />
		<?php
	}
	else
	{
		?>
		<strong><a href="<?php echo $_SERVER['PHP_SELF'] ?>?adminlogin=1">Log into admin mode</a></strong>.<br /><br />
	<?php
	}
?>

By logging in as admin, you will be able to post messages to the main listing, and also bypass html stripping/mctagification.  Make sure that no one (that you don't want) gets access to setup.php, otherwise they will be able to set the admin cookie to themselves.  If in doubt, you can rename setup.php to whatever you want (.php).<br /><br />

This function utilizes cookies.
</body>
</html>
