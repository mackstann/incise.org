<?php

// McData Version 0.2

// McData, (c) 2002 mackstann
// License:	GNU General Public License
//		(see LICENSE.txt)

//when you log into admin mode, this is the username
//that will automatically be used.  if you dont want
//this feature, and want to be able to log into admin
//mode but still be able to type in a user name (for
//example, if you have multiple admin people), just
//comment this line out by putting two slashes (//)
//in front of it.
$conf['username']      = "Put Your Name Here";

//change this to "Tags" or whatever you want
//if "McTags" doesnt suit you
$conf['tagname']       = "McTags";

//if this is set to yes, then on the message submit
//form, it will say "Hello <ip address>" at the top.
//"yes" turns it on and "no" turns it off.  Hello IP
//does not appear to a logged in admin, instead it
//will say Hello username.
$conf['helloip']       = "yes";

//change to bottom, if you want the form to appear below
//the messages.
$conf['formplacement'] = "top";

//these should be pretty self explanatory, edit them
//to fit your situation
$conf['mysql_host']    = "localhost";
$conf['mysql_dbname']  = "McData";

// **** YOU MUST EDIT THESE TWO VARIABLES!!! ****
$conf['mysql_user']    = "user";
$conf['mysql_pass']    = "pass";

/*----------------------------------------------------------------------------\
| configuration ends and code begins! (if unsure, dont edit past this point!) |
\----------------------------------------------------------------------------*/

//set up the mysql connection
$conf['db']            = mysql_connect($conf['mysql_host'],$conf['mysql_user'],$conf['mysql_pass']);

function McData($conf)
{
	
	//select the database
	mysql_select_db($conf['mysql_dbname'],$conf['db']);
	
	//see if we want the form at the top, if so, then
	//put the form here
	if($conf['formplacement'] != "bottom")
		makeform($conf);

	//see if we need to submit a message
	submitpost($conf);

	//print the appropriate messages for the page
	printposts($conf);
	
	//see if we want form at bottom, if so, make it
	if($conf['formplacement'] == "bottom")
		makeform($conf);
}

/*
 * replies() - count how many replies there are to a post by counting
 * the number of other posts whos parentid corresponds to the given
 * message id.  replies() is called by printrow()
 */
function replies($row,$conf)
{
	//count how many posts' parentid equals the current message id.
	$countreplies = mysql_query("SELECT count(*) FROM posts WHERE parentid = '" . $row['mid'] . "'", $conf['db']);
	$replies = mysql_result($countreplies,0,0);
	return $replies;
}

/*
 * clickyurls() - turns urls into links.  this becomes <a href="this">this</a>
 */
function clickyurls($string)
{
	$string = preg_replace("/((http(s?):\/\/)|(www\.))(\S+)/i","<a href=\"http$3://$4$5\">$2$4$5</a>", $string);
	return $string;
}

/*
 * mctags() - replace special mctags ([b], [i], [l]) with the
 * corresponding html
 */
function mctags($string)
{
	$string = eregi_replace("\[B](.*)[/B]","<strong>\\1</strong>",$string);
	$string = eregi_replace("\[I](.*)[/I]","<em>\\1</em>",$string);
	
	return $string;
}			

/* 
 * makeform() - print out the form for submitting posts
 */
function makeform($conf)
{
	//if there's a message id with a real value, then make the form
	//bring you back to that page after you submit
	
	//if there is a ?mid= specified in the url,
	if(isset($_GET['mid']) && $_GET['mid'] != 0)
	{
		//make sure its a parent message, otherwise whine and die
		$result = mysql_query("SELECT parentid FROM posts WHERE mid=\"" . $_GET['mid'] . "\"",$conf['db']);
		while($row = mysql_fetch_assoc($result))
		{
			if($row['parentid'] != 0)
				die("MCDATA ERROR: mid given points to a child message");
		}
		
		//and since there is a ?mid=, make the form return to
		//this same message after posting
		$returnurl = "./?mid=" . $_GET['mid'];
	}
	
	//otherwise, return you to the main page (only used by admin-person)
	else
	{	
		if($_COOKIE['mcdata-admin'] != 1)
			return;
		$returnurl = ".";
	}
	
	if($_COOKIE['mcdata-admin'] && isset($conf['username']))
		$user = "<p>Hello <input type=\"hidden\" name=\"name\" value=\"" . $conf['username'] . "\"></input><strong class=\"mcdata-adminname\">" . $conf['username'] . "</strong></p>";
	else
		$user = "<p>name:<br /><input type=\"text\" name=\"name\" size=\"30\" maxlength=\"16\" class=\"mcdata-namebox\"></input></p>";
	
	//html time! basically, just make the form.  self explanatory.
	?>
	
	<!-- McData Form begins -->
	<p>
	<div class="mcdata-form">
	<form method="post" action="<?=$returnurl?>">
		<strong class="mcdata-tags-title"><?=$conf['tagname']?></strong>:  <strong class="mcdata-tags">[b]</strong>bold<strong class="mcdata-tags">[/b]</strong> and <strong class="mcdata-tags">[i]</strong>italic<strong class="mcdata-tags">[/i]</strong>
		
		<p>URLs with the <strong class="mcdata-http">http://</strong> in front are automatically linked.</p>

		<?php 	if($conf['helloip'] == "yes" && ! $_COOKIE['mcdata-admin'])
			{
				?>
				<p>Hello <strong class="mcdata-ip"> <?=$_SERVER['REMOTE_ADDR']?></strong></p>
				<?php
			}
		?>
		
		<?php echo $user; ?>
		
		<p>
		message:
		<br />
		<textarea name="message" rows="4" cols="30" class="mcdata-messagebox"></textarea>
		
		<br />
		<input type="submit" name="submithit" value="Submit" class="mcdata-submitbutton"></input> <?php if(isset($_GET['mid'])) { ?> &lt;&lt; <a href="." class="mcdata-back">back</a> <?php } ?>
		</p>
	</form>
	</div>
	</p>
	<!-- Form over -->
	
	<?php
	//and our form is done
}

/*
 * submitpost() - submit a post into the database
 */
function submitpost($conf)
{
	//check if name and message have been submitted, if so, continue,
	//if not, then don't submit anything to the McDB
	if(! isset($_POST['name']) || ! isset($_POST['message']))
		return;
	
	//if there is a mid, then assign this post's parentid to that mid
	//so it shows up as a child of that post
	if($_GET['mid'])
		$pid = $_GET['mid'];

	//otherwise the parentid is zero, and it will show up on the main
	//listing
	else
		$pid = 0;

	$name = trim($_POST['name']);
	$message = trim($_POST['message']);

	$message = eregi_replace("\n","<br />",$message);
	$message = clickyurls($message);
					
	
	if($_COOKIE['mcdata-admin'] != 1)
	{
		$name = strip_tags($name);
		$message = strip_tags($message);
		$message = mctags($message);
	}
	
	
	//now insert the post into the db
$sql = "INSERT INTO posts (name,date,message,parentid) VALUES ('" . $name . "',NOW(),'" . $message . "','" . $pid . "')";
	$result = mysql_query($sql);
}

/*
 * loadposts() - load up the posts from the db to show on the page
 */
function loadposts($conf)
{
	//if we're inside a message, load its children
	if(isset($_GET['mid']))
		$result = mysql_query("SELECT name, date, message, mid FROM posts WHERE mid=\"" . $_GET['mid'] . "\" OR parentid=\"" . $_GET['mid'] . "\" ORDER BY mid DESC",$conf['db']);
	
	//otherwise just display all messages
	else
		$result = mysql_query("SELECT name, date, message, mid FROM posts WHERE parentid=\"0\" ORDER BY mid DESC",$conf['db']);
	
	return $result;
}		

/*
 * printposts() - print out the posts!
 */
function printposts($conf)
{
	//load the posts
	$result = loadposts($conf);
	
	echo "\n<!-- McData Begins! -->\n";
	
	//print the posts
	while($row = mysql_fetch_assoc($result))
		printrow($row,$conf);

	//wrap it up
	echo "\n<!-- End of McData stream -->\n";
}

/*
 * printrow() - its called for each post by printposts(), it does the work
 * of laying out the html and stuff for each post
 */
function printrow($row,$conf)
{
	//print the 'Posted by Suchandsuch @ YYYY-MM-DD HH:MM:SS'
	//and print the message
	?>
	<p />

	<div class="mcdata-div">
		<span class="mcdata-postedby">Posted by </span><strong class="mcdata-name"><?php echo $row['name']?></strong><span class="mcdata-date"> @ <?php echo $row['date']?></span>
		
		<p><span class="mcdata-message"><?php echo $row['message']?></span></p>
	<?php

	//now check if we need to print the view/reply line
	if(! isset($_GET['mid']))
	{	
		//call replies() to calculate the # of replies for this post
		$replies = replies($row,$conf);
		//use correct english : )
		if($replies == 1) $word = "reply"; else $word = "replies";

		//X replies - View/Reply
		?>
		<strong class="mcdata-replies"><?php echo $replies?> <?php echo $word?></strong> - <a href="./?mid=<?php echo $row['mid']?>" class="mcdata-viewreply">View/Reply</a>
		<?php
	}
	?>

	</div>
	<?php
}

//and now, put it to action!

McData($conf);

//thats it!

?>
