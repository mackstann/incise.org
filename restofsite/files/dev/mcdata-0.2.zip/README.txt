McData README

## <contact> ------------------------------------------------------------------

Please contact me and tell me what you think of McData.  Bugs, problems,
complaints, suggestions, anything, let me know!

site:	http://mackstann.cjb.net/
email:	mackstann at myrealbox.com
IRC:	mackstann @ OPN, mackstann @ EFNet
AIM:	Millenium Mullah

## </contact> -----------------------------------------------------------------

## <admin> --------------------------------------------------------------------

The admin login is at the bottom of setup.php.  By logging in, it sets a cookie
to your browser which McData checks for.  By being logged in, you can post new
messages (not just replies), and your text is not stripped of html, or mctag-
ified.  Make sure to not let anyone access setup.php unless you want them to
have admin privelages with McData.  You can rename setup.php to anything you
want as long as it ends in .php and put it anywhere in your web server's
directory tree, as long as it's on the same webserver it will work just fine.

## </admin> -------------------------------------------------------------------

## <css> ----------------------------------------------------------------------

McData uses CSS for formatting.  You can leave it as-is and it will
use the CSS (if you have any) from your site, and blend in.  You can
also customize it with McData's CSS classes.

The classes for the posts are :

     div.mcdata-div
        .mcdata-postedby
  strong.mcdata-name
        .mcdata-date
        .mcdata-message
  strong.mcdata-replies
       a.mcdata-viewreply

There are also classes for the form:

     div.mcdata-form
  strong.mcdata-tags-title
  strong.mcdata-tags
  strong.mcdata-ip
  strong.mcdata-http
  strong.mcdata-adminname
   input.mcdata-namebox
textarea.mcdata-messagebox
   input.mcdata-submitbutton
       a.mcdata-back

Have a look at the source of a page with McData and these should all
be pretty self explanatory, if you know CSS, and should allow
you to customize the format quite a bit.  If you don't know CSS,
here's a great place to get started:

http://www.w3.org/MarkUp/Guide/Style

## </css> ---------------------------------------------------------------------

## <xhtml> --------------------------------------------------------------------

McData is Valid XHTML 1.0 Transitional markup.

http://validator.w3.org/

## </xhtml> -------------------------------------------------------------------

## <mid> ----------------------------------------------------------------------

The way McData sorts messages is by using mid as a MySQL primary key,
and using auto_increment for it, so mid is never the same for any two
messages.  mid is short for message identifier.

## </mid> ---------------------------------------------------------------------

## <parentid>------------------------------------------------------------------

parentid is how McData determines what type of a message it's dealing
with.  If the parentid is zero, then the post *is* a parent and
appears on the main listing out front.  If the message is a child of
another message, then its parentid corresponds to the mid of its
parent.  There is only one layer of nesting.

## </parentid> ----------------------------------------------------------------

## <mctags> -------------------------------------------------------------------

McTags are explained on the message posting form, and are similar to
what is used in most BB's, you use tags with brackets instead of
html, because allowing html is dangerous.  It would be fairly easy
to, say, only allow <strong>, and <em>, but with just an <em> you
can embed some nasty javascript that could do god knows what, even
if it's nothing more than be annoying.  Sure this isn't very likely
on a small site, but who knows what people will do.  I will probably
make mctags and html stripping optional in the future, but I wouldn't
recommend going without them.  McTags and html stripping are bypassed
in admin mode.

## </mctags> ------------------------------------------------------------------

## <multiple instances> -------------------------------------------------------

Multiple instances of McData will work just fine, what you will want to do is
copy setup.php and mcdata.php (their filenames dont matter, or you can just put
copies in another directory), and edit the copies to have a different MySQL
database name (default is McData), then run the new setup.php and it will set
up the new db and then you can just include the second mcdata.php for your
second instance of McData.  You should be able to do this as many times as you
want.

## </multiple instances> ------------------------------------------------------

## <quality assurance> --------------------------------------------------------

I have attempted to make McData a high quality and standards compliant piece
of software.  McData is valid XHTML 1.0 Transitional, valid CSS2, and produces
no PHP warnings when using error_reporting(E_ALL).  If you see any mistakes
please let me know.

## </quality assurance> -------------------------------------------------------

EOF
