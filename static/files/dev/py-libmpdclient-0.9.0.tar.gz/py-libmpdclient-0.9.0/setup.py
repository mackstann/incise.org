#!/usr/bin/env python

# $Id: setup.py,v 1.4 2003/09/30 00:47:40 mackstann Exp $

from distutils.core import setup

setup(
  name="py-libmpdclient",
  version="0.9.0",
  description="Python client library for mpd (Music Player Daemon)",
  author="Nick Welch aka mackstann",
  author_email="mack at incise dot org",
  url="http://www.musicpd.org/?page=python_module",
  py_modules=['mpdclient'],
  license="GNU Lesser General Public License, see source or COPYING.txt "\
          "for full license text"
)

