<?php

/*
                 ____.             __               
 /'\_/`\        /\  _ \.          /\ \__            
/\      \    ___\ \ \/\ \     __  \ \ ,_\    __     
\ \ \__\ \  /'___\ \ \ \ \  /'__`\ \ \ \/  /'__`\   
 \ \ \_/\ \/\ \__/\ \ \_\ \/\ \L\.\_\ \ \_/\ \L\.\_ 
  \ \_\\ \_\ \____\\ \____/\ \__/.\_\\ \__\ \__/.\_\
   \/_/ \/_/\/____/ \/___/  \/__/\/_/ \/__/\/__/\/_/
	
*/

// McData, (c) 2002 mackstann
// license:	GNU General Public License
//		(see LICENSE.txt)

//change the key here, for example, $key = "letmein";
$key = "key";

//change this to "Tags" or whatever you want
//if "McTags" doesnt suit you
$tagname = "McTags";

//if this is set to yes, then on the message submit
//form, it will say "Hello <ip address>" at the top.
//change "yes" to anything else and this message
//will not be displayed.  The main reason I did this
//was to scare off any really ignorant people from
//posting stupid things (you know, the ones who think
//that an IP address is some sort of magical thing
//and worry that they might get tracked down with it)
$helloip = "no";

function McData()
{
/*---------------------------------------------------\
| these should be pretty self explanatory, edit them |
| to fit your situation                              |
\---------------------------------------------------*/

	$mysql_host   = "localhost";
	$mysql_user   = "user";
	$mysql_pass   = "pass";
	$mysql_dbname = "McData";

/*---------------------------------------------------------------------------\
| configuration ends and code begins!                                        |
\---------------------------------------------------------------------------*/

	//set up the mysql connection
	$db = mysql_connect($mysql_host,$mysql_user,$mysql_pass);
	
	//select the database
	mysql_select_db($mysql_dbname,$db);
	
	//should we put a form on the page or not?
	formdecision($db);

	//if this page is the result of a person posting a message,
	//and they filled in both name and message fields, then
	//submit the post.
	if($_POST['name'] && $_POST['message'])
		submitpost($_POST['name'],$_POST['message']);

	//load the posts from the database
	$result = loadposts($db,$_GET['mid']);

	//and print them out
	printposts($result,$mysql_dbname);
}

/* formdecision() - figure out whether we are inside of a post
 * or out on the main listing, and decide to make the form or not
 * based on that
 */
function formdecision($db)
{
	//if there's a mid, that means we're inside of a post,
	//so we make the form
	if($_GET['mid'])
		makeform($_GET['mid'],$db);
	
	//otherwise, we dont make the form
	else
	{
		//unless we put the secret key in!
		if($_GET[$GLOBALS['key']] == 1)
			makeform(0,$db);
	}
}				

/* replies() - count how many replies there are to a post by counting
 * the number of other posts whos parentid corresponds to the given
 * message id.  replies() is called by printrow()
 */
function replies($mid,$mysql_dbname)
{
	//count how many posts' parentid equals the current message id.
	$countreplies = mysql_db_query($mysql_dbname,"SELECT count(*) FROM posts WHERE parentid = '$mid'");

	//and return it
	$replies = mysql_result($countreplies,0,0);
	return $replies;
}

/* mctags() - replace special mctags ([b], [i], [l]) with the
 * corresponding html
 */
function mctags($string)
{
	//do the [l] tags
	$string = eregi_replace("\[L=(.*)]","<a href=\"\\1\">",$string);
	$string = eregi_replace("\[/L]","</a>",$string);
	
	//[b] tags
	$string = eregi_replace("\[B]","<strong>",$string);
	$string = eregi_replace("\[/B]","</strong>",$string);

	//[i] tags
	$string = eregi_replace("\[I]","<em>",$string);
	$string = eregi_replace("\[/I]","</em>",$string);
	
	//now return the mctagified message
	return $string;
}			

/* makeform() - print out the form for submitting posts
 */
function makeform($mid,$db)
{
	//if there's a message id with a real value, then make the form
	//bring you back to that page after you submit
	
	//if there is a ?mid= specified in the url,
	if($mid != 0)
	{
		//make sure its a parent message, otherwise whine and die
		$result = mysql_query("SELECT * FROM posts WHERE mid=\"$mid\"",$db);
		while($row = mysql_fetch_row($result))
		{
			$parentid = $row[3];
			if($parentid != 0)
				die("MCDATA ERROR: mid given points to a child message");
		}
		
		//and since there is a ?mid=, make the form return to
		//this same message after posting
		$returnurl = "./?mid=" . $mid;
	}
	
	
	//otherwise, return you to the main page (only used by admin-person)
	else
		$returnurl = ".";
	
	//html time! basically, just make the form.  self explanatory.
	?>
	
	<div class="sub">
	<form method="post" action="<?=$returnurl?>">
		<strong><?=$GLOBALS['tagname']?></strong>:  
		<strong>[L=http://url]</strong>hypertext link
		<strong>[/L]</strong>, 
		<strong>[b]</strong>bold<strong>[/b]</strong>, and 
		<strong>[i]</strong>italic<strong>[/i]</strong>
		
		<br /><br />
		
		<?php 	if($helloip == "yes")
			{
				?>
				Hello <strong> <?=$_SERVER['REMOTE_ADDR']?></strong>
				<br /><br />
				<?php
			}
		?>
		
		name:<br />
		<input type="text" name="name" size="30" maxlength="16" class="textbox"></input>
		
		<br /><br />
		
		message:
		<br />
		<textarea name="message" rows="4" cols="30" class="textbox"></textarea>
		
		<br />
		<input type="submit" name="submithit" value="Submit" class="button"></input>
	</form>
	</div>
	
	<?php
	//and our form is done
}

/* submitpost() - submit a post into the database
 */
function submitpost($name,$message)
{
	//if there is a mid, then assign this post's parentid to that mid
	//so it shows up as a child of that post
	if($_GET['mid'])
		$pid = $_GET['mid'];

	//otherwise the parentid is zero, and it will show up on the main
	//listing
	else
		$pid = 0;
	
	//now insert the post into the db
	$sql = "INSERT INTO posts (name,date,message,parentid) VALUES ('$name',NOW(),'$message','$pid')";
	$result = mysql_query($sql);
}

/* loadposts() - load up the posts from the db to show on the page
 */
function loadposts($db,$mid)
{
	//if we're inside a message, load its children
	if($mid)
	{
		$result = mysql_query("SELECT * FROM posts WHERE mid=\"$mid\" OR parentid=\"$mid\" ORDER BY mid DESC",$db);
	}
	
	//otherwise just display all messages
	else
	{
		$result = mysql_query("SELECT * FROM posts WHERE parentid=\"0\" ORDER BY mid DESC",$db);
	}
	return $result;
}		

/* printposts() - print out the posts!
 */
function printposts($result,$mysql_dbname)
{
	echo "\n<!-- McData Begins! -->\n";
	
	//for every post
	while($row = mysql_fetch_row($result))
	{
		//strip the tags and mctagify, UNLESS its the admin!
		//if its the admin, then html is accepted
		if($_GET[$key] != 1)
		{
			$row[0] = strip_tags($row[0]);
			$row[2] = strip_tags($row[2]);
			$row[2] = mctags($row[2]);
		}
		//print the row
		printrow($row[0],$row[1],$row[2],$row[4],$mysql_dbname);
	}

	//wrap it up
	echo "<br />";
	echo "\n<!-- End of McData stream -->\n";
}

/* printrow() - its called for each post by printposts(), it does the work
 * of laying out the html and stuff for each post
 */
function printrow($thename,$thedate,$themessage,$mid,$mysql_dbname)
{
	//if we're inside a message, then print the 'simple' version
	if($_GET['mid'])
	{
		printf("\n<br /><div class=\"mcdata-div\">\n<span class=\"mcdata-postedby\">Posted by </span><strong class=\"mcdata-name\">%s</strong><span class=\"mcdata-date\"> @ %s</span>\n<p>\n<span class=\"mcdata-message\">%s</span>\n</p>\n</div>\n\n",$thename,$thedate,$themessage);
	}

	//and if we're outside on the main listing, then show the number
	//of replies, and the view/reply button.
	else
	{	
		//call replies() to calculate the # of replies for this post
		$replies = replies($mid,$mysql_dbname);
		
		//use correct english : )
		$word = "replies";
		if($replies == 1)
			$word = "reply";

		//print the html
		printf("\n<br /><div class=\"mcdata-div\">\n<span class=\"mcdata-postedby\">Posted by </span><strong class=\"mcdata-name\">%s</strong><span class=\"mcdata-date\"> @ %s</span>\n<p>\n%s\n</p>\n<strong class=\"mcdata-replies\">%s %s</strong> - <a href=\"%s?mid=%s\">View/Reply</a>\n<br />\n</div>\n\n",$thename,$thedate,$themessage,$replies,$word,$_SERVER['PHP_SELF'],$mid);
	}
}

//and now, put it to action!

McData();

//thats it!

?>
