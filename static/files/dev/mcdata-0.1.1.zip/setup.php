<?php

//should be fine in most cases
$mysql_host   = "localhost";

//you MUST change these!
$mysql_user   = "user";
$mysql_pass   = "pass";

//change if you want, makes no difference really
$mysql_dbname = "McData";

//db
echo "(Connecting to MySQL)<br /><br />";
$db = mysql_connect($mysql_host,$mysql_user,$mysql_pass) or die("Couldnt connect to MySQL");
if($db) echo "(Successfully connected to MySQL)<br /><br />";

$db_list = mysql_list_dbs($db);

while ($row = mysql_fetch_object($db_list))
{
	if($row->Database == $mysql_dbname)
	{
		$mcdatafound = 1;
		echo "(McDatabase found)<br /><br />";
	}
}

if($mcdatafound != 1)
{
	$query = "create database " . $mysql_dbname;
	mysql_query($query) or die("Couldnt create database!");
	echo "database created!<br /><br />";
}
else
	echo "McDatabase found!<br /><br />";

//table

$table_list = mysql_list_tables($mysql_dbname);

while($trow = mysql_fetch_row($table_list))
{
	if($trow[0] == "posts")
		$postsfound = 1;
		echo "(table found)<br /><br />";
}

if($postsfound != 1)
{
	$query = "create table posts (name VARCHAR(24) NOT NULL,date VARCHAR(24) NOT NULL,message TEXT NOT NULL,parentid INT NOT NULL,mid INT NOT NULL AUTO_INCREMENT,PRIMARY KEY (mid))";
	mysql_query($query) or die("Couldnt create table!");
	echo "table \"posts\" created.<br /><br />";
}
else
	echo "table \"posts\" found!";

?>
