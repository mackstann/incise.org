McData README

## <contact> ------------------------------------------------------------------

Please contact me and tell me what you think of McData.  Bugs, problems,
complaints, suggestions, anything, let me know!

site:	http://mackstann.cjb.net/
email:	mackstann at myrealbox.com
IRC:	mackstann @ OPN, mackstann @ EFNet
AIM:	Millenium Mullah

## </contact> -----------------------------------------------------------------

## <key> ----------------------------------------------------------------------

The 'admin' key is "?key=1".  for example if your page with McData
is at:

	http://something.com/index.php

You would change it to:

	http://something.com/index.php?key=1

Or if there are already other variables there, use a & like this:

	http://something.com/index.php?s=yes&key=1

Using the admin key turns off html stripping, so you can use normal
HTML and even PHP in your post, and bypasses McTag replacement.  It
also allows you to post messages on the main index, where normal
users can only post replies.  This key system will most likely be
replaced with something more elegant soon.

You can change the key in mcdata.php right near the top by editing
the value of $key.

## </key> ---------------------------------------------------------------------

## <css> ----------------------------------------------------------------------

McData uses CSS for formatting.  You can leave it as-is and it will
use the CSS (if you have any) from your site, and blend in.  You can
also customize it with McData's CSS classes.  Here's what the html of
a McData post looks like:

<br /><div class="mcdata-div">
<span class="mcdata-postedby">Posted by </span><strong class="mcdata-name">mackstann</strong><span class="mcdata-date"> @ 2002-07-10 07:23:06</span>
<p>
<span class="mcdata-message">This is a sample message</span>
</p>
<strong class="mcdata-replies">2 replies</strong> - <a href="/mcdata/index.php?mid=1">View/Reply</a>
<br />
</div>

Notice the classes.  there are 6:

   div.mcdata-div
      .mcdata-postedby
strong.mcdata-name
      .mcdata-date
      .mcdata-message
strong.mcdata-replies

These are pretty self explanatory if you know CSS, and should allow
you to customize the format quite a bit.  If you don't know CSS,
a good place to start would be here:

http://www.w3.org/MarkUp/Guide/Style

it's a very good beginner's tutorial on CSS, and lays things out in
a way that's easy to understand and put to use quickly.

## </css> ---------------------------------------------------------------------

## <mid> ----------------------------------------------------------------------

The way McData sorts messages is by using mid as a MySQL primary key,
and using auto_increment for it, so mid is never the same for any two
messages.  mid is short for message identifier.

## </mid> ---------------------------------------------------------------------

## <parentid>

parentid is how McData determines what type of a message it's dealing
with.  If the parentid is zero, then the post *is* a parent and
appears on the main listing out front.  If the message is a child of
another message, then its parentid corresponds to the mid of its
parent.  There is only one layer of nesting.

## </parentid> ----------------------------------------------------------------

## <mctags> -------------------------------------------------------------------

McTags are explained on the message posting form, and are similar to
what is used in most BBS's, you use tags with brackets instead of
html, because allowing html is dangerous.  It would be fairly easy
to, say, only allow <a>, <strong>, and <em>, but with just an <a>
you can embed some nasty javascript that could do god knows what,
even if it's nothing more than be annoying.  Sure this isn't very
likely on a small site, but who knows what people will do.  I will
probably make mctags and html stripping optional in the future, but
I wouldn't recommend going without them.

## </mctags> ------------------------------------------------------------------

EOF
